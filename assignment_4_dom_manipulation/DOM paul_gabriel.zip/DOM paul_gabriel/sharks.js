
const h1 = document.getElementsByTagName('h1')[0];
const p = document.getElementsByTagName('p')[0];
const ul = document.getElementsByTagName('ul')[0];

const ul1 = document.getElementsByTagName('ul1')[1];
const html = document.documentElement;

console.log(p.parentNode); 

console.log(p.parentNode.parentNode); 

console.log(p.parentNode.parentNode.parentNode);
console.log(html.parentNode); 

console.log(p.parentNode.parentNode.parentNode.parentNode); 

console.log(ul.childNodes); 

ul.firstElementChild.style.background = 'aqua';

for (let i of ul.children) {
	i.style.background = 'gold';
}

document.body.children[3].lastElementChild.style.background = 'fuchsia';

const green = ul.children[2];

green.nextElementSibling.style.backgroundColor = 'coral';

green.previousElementSibling.style.backgroundColor = 'aqua';

const typesOfSharks = document.querySelector('ul');
const newType = document.createElement('li');

newType.textContent = 'thresher shark';
typesOfSharks.appendChild(newType);

anotherType = document.createElement('li');
anotherType.textContent = 'ghost shark';
typesOfSharks.insertBefore(anotherType, typesOfSharks.firstElementChild);

anotherType = document.createElement('li');
anotherType.textContent = 'bignose shark';
typesOfSharks.insertBefore(anotherType, typesOfSharks.firstElementChild);


anotherType = document.createElement('li');
anotherType.textContent = 'finetooth shark';
typesOfSharks.insertBefore(anotherType, typesOfSharks.firstElementChild);

const modifyTypes = document.createElement('li');

modifyTypes.textContent = 'bronze whaler shark';
typesOfSharks.replaceChild(modifyTypes, typesOfSharks.children[5]);

typesOfSharks.removeChild(typesOfSharks.lastElementChild);

typesOfSharks.removeChild(typesOfSharks.firstElementChild);

newType.textContent = '	bigeye thresher';
typesOfSharks.appendChild(newType);
